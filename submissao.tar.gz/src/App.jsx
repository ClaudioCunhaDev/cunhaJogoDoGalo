import react from "react";
import { JogoDoGalo } from "./Components/JogoDoGalo";

function App() {
  return (
    <>
      <JogoDoGalo />
    </>
  );
}

export default App;
